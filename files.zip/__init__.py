"""
mlb_core.config v2 — GCP-aware.

All paths are resolved from environment variables so the same codebase
runs on a developer's Windows machine and on Cloud Run without changes.

Environment variables (set in Cloud Run or .env locally):
    MLB_GCS_BUCKET      GCS bucket name, e.g. "mlb-betting-data"
                        When set, data reads/writes go through GCS.
                        When absent, falls back to MLB_BASE_DATA local path.
    MLB_BASE_DATA       Local root for Baseball_Data (dev only).
                        Defaults to ~/Baseball_Data.
    MLB_BASE_DIR        Local root for the repo (dev only).
                        Defaults to parent of this file's package.
    MLB_DB_URL          SQLAlchemy URL for Cloud SQL, e.g.
                        postgresql+pg8000://user:pass@/db?unix_sock=/cloudsql/...
                        When absent, falls back to SQLite.
    GCP_PROJECT         GCP project id, e.g. "my-mlb-project"
    GCP_REGION          GCP region, default "us-central1"
"""
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# GCP settings
# ---------------------------------------------------------------------------
GCP_PROJECT = os.getenv("GCP_PROJECT", "")
GCP_REGION  = os.getenv("GCP_REGION", "us-central1")
GCS_BUCKET  = os.getenv("MLB_GCS_BUCKET", "")          # empty = local mode
DB_URL      = os.getenv("MLB_DB_URL", "")               # empty = SQLite

# ---------------------------------------------------------------------------
# Local paths (dev / fallback)
# ---------------------------------------------------------------------------
_repo_root  = Path(__file__).resolve().parents[2]
BASE_DATA   = Path(os.getenv("MLB_BASE_DATA",
                             str(Path.home() / "Baseball_Data")))
BASE_DIR    = Path(os.getenv("MLB_BASE_DIR", str(_repo_root)))

# ---------------------------------------------------------------------------
# Shared data paths (local equivalents — mirrored in GCS when GCS_BUCKET set)
# ---------------------------------------------------------------------------
STATCAST_MASTER  = BASE_DATA / "Statcast" / "statcast_master.csv"
WEATHER_MASTER   = BASE_DATA / "Weather"  / "weather_master.csv"
LINEUPS_MASTER   = BASE_DATA / "Lineups"  / "lineups_master.csv"
UMPIRES_MASTER   = BASE_DATA / "Umpires"  / "umpscorecards_master.csv"
ODDS_DIR         = BASE_DATA / "Odds" / "DraftKings"

# ---------------------------------------------------------------------------
# Season params
# ---------------------------------------------------------------------------
SEASON_START_MONTH = 3
SEASON_END_MONTH   = 11
TIMEZONE           = "America/New_York"

# ---------------------------------------------------------------------------
# Cache dirs
# ---------------------------------------------------------------------------
DEFAULT_STATCAST_CACHE = BASE_DATA / "Statcast" / "cache_daily"
DEFAULT_WEATHER_CACHE  = BASE_DATA / "Weather"  / "cache_daily"
DEFAULT_LINEUP_CACHE   = BASE_DATA / "Lineups"  / "cache_daily"

# ---------------------------------------------------------------------------
# GCS key prefixes (mirrors local structure inside the bucket)
# ---------------------------------------------------------------------------
GCS_PREFIX_STATCAST = "Statcast"
GCS_PREFIX_WEATHER  = "Weather"
GCS_PREFIX_LINEUPS  = "Lineups"
GCS_PREFIX_UMPIRES  = "Umpires"
GCS_PREFIX_MODELS   = "models"

def is_gcs_mode() -> bool:
    """True when running in GCP / GCS mode."""
    return bool(GCS_BUCKET)

def is_cloud_sql_mode() -> bool:
    """True when a Cloud SQL DB URL is provided."""
    return bool(DB_URL)
