# mlb-betting v2 — GCP Migration

## What changed from v1

| Area | v1 | v2 |
|------|----|----|
| Paths | Hardcoded `C:\Users\lmayn\...` | Env vars with sensible defaults |
| Database | SQLite (ephemeral) | Cloud SQL / Postgres (+ SQLite fallback for dev) |
| File storage | Local CSV/pkl | GCS (+ local fallback for dev) |
| DK scraper | Selenium + Chrome | Direct HTTP — no browser needed |
| Deployment | Notebooks only | Cloud Run + Cloud Scheduler |
| Discord | Not present | Webhook publisher in `mlb_core.notify` |
| `sys.path` hacks | In every section0 file | Gone — `mlb_core` installed as a package |

Original notebooks and v1 files are **untouched**. The v2 files live alongside them.

---

## Directory structure

```
mlb-betting/
├── mlb_core/              ← shared library (v2 drop-in)
│   ├── config/            ← env-var based config (replaces config.py)
│   ├── storage.py         ← GCS / local transparent file layer (NEW)
│   ├── data/              ← unchanged from v1
│   ├── models/            ← unchanged from v1
│   ├── odds/
│   │   ├── dk_scraper.py  ← HTTP scraper, no Selenium (v2)
│   │   └── utils.py       ← unchanged
│   ├── tracking/
│   │   └── bet_tracker.py ← SQLAlchemy, Cloud SQL support (v2)
│   └── notify/
│       └── discord.py     ← Discord webhook publisher (NEW)
├── NRFI_Pro_System/
│   └── config_nrfi.py     ← env-var paths (v2)
├── HR_Pro/
│   └── config_hr.py       ← env-var paths (v2)
├── F5_Pro_System/
│   └── config_f5.py       ← env-var paths (v2)
├── K_Pro_System/
│   └── config_k.py        ← env-var paths (v2)
├── runners/               ← Cloud Run system runners (NEW)
│   ├── run_nrfi.py
│   ├── run_hr.py
│   ├── run_f5.py
│   └── run_k.py
├── main.py                ← Flask entrypoint for Cloud Run (NEW)
├── Dockerfile
├── requirements.txt
├── setup.py               ← v2 with GCP deps
├── .env.example
└── deploy/
    ├── deploy.sh          ← one-shot bootstrap script
    └── deploy_update.sh   ← fast redeploy
```

---

## Local development (Windows, no GCP)

```bash
# 1. Copy env file
cp .env.example .env
# Edit .env — set MLB_BASE_DATA and MLB_BASE_DIR to your Windows paths
# Leave MLB_GCS_BUCKET and MLB_DB_URL empty

# 2. Install
pip install -e .

# 3. Test imports
python -c "from mlb_core.config import is_gcs_mode; print('GCS mode:', is_gcs_mode())"

# 4. Run Flask locally
python main.py
# POST to http://localhost:8080/run
```

---

## GCP deployment (first time)

```bash
# 1. Set your project
export PROJECT_ID=my-gcp-project

# 2. (Optional) set Discord webhook
export DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...

# 3. Run the bootstrap script
chmod +x deploy/deploy.sh
./deploy/deploy.sh
```

The script will:
- Enable all required GCP APIs
- Create a GCS bucket
- Create a Cloud SQL Postgres instance
- Store secrets in Secret Manager
- Build the Docker image via Cloud Build
- Deploy to Cloud Run
- Create two Cloud Scheduler jobs (9 AM ET + 5 PM ET)

---

## Uploading model files to GCS

```bash
BUCKET=my-gcp-project-mlb-data

# NRFI models
gsutil cp NRFI_Pro_System/models/*.json  gs://$BUCKET/NRFI_Pro_System/models/
gsutil cp NRFI_Pro_System/models/*.pkl   gs://$BUCKET/NRFI_Pro_System/models/

# HR models
gsutil cp HR_Pro/models/*.json gs://$BUCKET/HR_Pro/models/
gsutil cp HR_Pro/models/*.pkl  gs://$BUCKET/HR_Pro/models/

# F5 models
gsutil cp F5_Pro_System/models/*.json gs://$BUCKET/F5_Pro_System/models/

# K models
gsutil cp K_Pro_System/models/*.json gs://$BUCKET/K_Pro_System/models/
```

---

## Wiring in your notebook prediction logic

Each `runners/run_*.py` file has a `_build_predictions()` stub:

```python
def _build_predictions(cfg, model, run_date: str) -> pd.DataFrame:
    # ── PASTE YOUR NOTEBOOK PREDICTION LOGIC HERE ──
    ...
```

Copy the relevant cells from your notebook (Sections 3–8 for NRFI, etc.)
into this function. The function must return a DataFrame with these columns:

| Column | Description |
|--------|-------------|
| `game_pk` | MLB game id |
| `away_team` | 3-letter abbrev |
| `home_team` | 3-letter abbrev |
| `model_prob` | Model probability |
| `market_prob` | Market implied prob (vig-removed) |
| `edge` | model_prob - market_prob |
| `kelly_pct` | Kelly fraction |
| `odds` | American odds (int) |
| `stake` | Dollar stake |

Only rows where `edge >= cfg["min_edge"]` should be returned.

---

## Testing a manual run

```bash
SERVICE_URL=$(gcloud run services describe mlb-betting \
  --region=us-central1 --format="value(status.url)")

# Data refresh only (safe to test)
curl -X POST "$SERVICE_URL/run" \
  -H "Authorization: Bearer $(gcloud auth print-identity-token)" \
  -H "Content-Type: application/json" \
  -d '{"systems":["NRFI"],"run_type":"data"}'

# Full run
curl -X POST "$SERVICE_URL/run" \
  -H "Authorization: Bearer $(gcloud auth print-identity-token)" \
  -H "Content-Type: application/json" \
  -d '{"systems":["NRFI","HR","F5","K"],"run_type":"morning"}'
```

---

## Discord channels

The notifier sends one message per system per run. To route systems to
different channels, set per-system webhook env vars:

```
DISCORD_WEBHOOK_NRFI=https://discord.com/api/webhooks/...nrfi-channel...
DISCORD_WEBHOOK_HR=https://discord.com/api/webhooks/...hr-channel...
DISCORD_WEBHOOK_F5=https://discord.com/api/webhooks/...f5-channel...
DISCORD_WEBHOOK_K=https://discord.com/api/webhooks/...k-channel...
```

Or use a single `DISCORD_WEBHOOK_URL` to post everything to one channel.
